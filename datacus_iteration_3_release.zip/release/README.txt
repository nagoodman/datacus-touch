<pre>
This is the root directory of the entire DATACUS system.  It contains the following
directories and files:

    doc			all documentation and presentations for the DATACUS project
    datacus.html		main page for the DATACUS project
    images		images used on the website
    src			all source code for the DATACUS project
    style.css		master style sheet for the DATACUS project
</pre>
